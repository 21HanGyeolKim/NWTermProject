package messenger;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.net.ServerSocket;
import java.net.Socket;

public class Server  {



}
