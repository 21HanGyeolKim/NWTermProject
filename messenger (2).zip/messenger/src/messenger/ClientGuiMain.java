package messenger;


import java.net.InetAddress;
import java.net.UnknownHostException;

public class ClientGuiMain {

	/*public static void main(String[] args) {
		// TODO Auto-generated method stub
		new Login();
		*//*try {
			InetAddress ia = InetAddress.getLocalHost();
			String ip_str = ia.toString();
			String ip = ip_str.substring(ip_str.indexOf("/") + 1);
			new ClientGui(ip, 5420);
			//db.updateLogin(tfUserId.getText());
		} catch (UnknownHostException he) {
			he.printStackTrace();
		}*//*
	}*/

}
