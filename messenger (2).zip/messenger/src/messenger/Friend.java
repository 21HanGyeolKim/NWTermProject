package messenger;

import org.json.simple.JSONObject;

public class Friend {
    String friendID;
    String friendName;

}
